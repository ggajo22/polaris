<?php
$conn = mysqli_connect("localhost", "root", "autoset");
mysqli_select_db($conn, "polaris2");
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <link rel="stylesheet" type="text/css" href="style.css">

    <link href="./res/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./res/jquery-ui/jquery-ui.min.css" rel="stylesheet">

    <style>
      th {
        text-align: center;
      }
    </style>
  </head>
  <body>

    <!-- 입력창 -->
    <form id="input_res" class="hidden" action="process.php" method="post">
      <p><input type="text" name="guest_name" placeholder="이름을 입력하세요"></p>
      <p><input type="text" name="room_id" placeholder="방번호를 선택하세요"></p>
      <p><input type="text" name="start_date" class="datepicker" placeholder="체크인 날짜를 입력하세요"></p>
      <p><input type="text" name="end_date" class="datepicker" placeholder="체크아웃 날짜를 입력하세요"></p>
      <p><input type="text" name="persons" placeholder="인원을 입력하세요"></p>
      <p><input type="text" name="total_price" placeholder="총액을 입력하세요"></p>
      <p><input type="text" name="paid_price" placeholder="지불액을 입력하세요"></p>
      <p><input type="text" name="payment_date" class="datepicker" placeholder="결제일을 선택하세요"?></p>
      <p><input type="text" name="created_by" placeholder="결제자를 입력하세요"></p>
      <p><input type="text" name="payment_method" placeholder="결제방법을 선택하세요"></p>
      <p><input type="submit" value="제출"></p>
    </form>
    <input type="button" id="input_res_btn" value="입력">

    <!-- 기준일 설정-->
    <input type="text" data-name="date_selected" id="date_selected" class="datepicker" placeholder="기준일을 선택하세요">

    <!-- 테이블 -->
    <table id="dustmq" border="1px" width="1900px" class="table-hover">
      <thead id="calendar">
      </thead>
      <tbody>
      </tbody>
    </table>

    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="./res/js/jquery-1.11.3.min.js"></script>
    <script src="./res/jquery-ui/jquery-ui.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="./res/bootstrap/js/bootstrap.min.js"></script>

<?php
  // room list 가져오기
  $result_room_list = mysqli_query($conn, "SELECT room_no, type FROM room");
  $rooms = array();
  $rooms_type = array();
  while($row_room_list = mysqli_fetch_assoc($result_room_list))
  {
    $rooms[] = $row_room_list['room_no'];
    $rooms_type[] = $row_room_list['type'];
  }

  // 예약 정보 가져오기
  $result = mysqli_query($conn, "SELECT date_of_stay, room_no, guest_name  FROM res as r LEFT JOIN res_info as ri ON r.res_info_id = ri.res_info_id LEFT JOIN room as rm ON ri.room_id = rm.room_id");
  $res_date = array();
  $res_room = array();
  $res_guest = array();
  while($row = mysqli_fetch_assoc($result))
  {
    $res_date[] = $row['date_of_stay'];
    $res_room[] = $row['room_no'];
    $res_guest[] = $row['guest_name'];
  }
 ?>

     <!-- 전체 테이블 만들기 -->
     <script type="text/javascript">
       $(document).ready(function(){
         // php로부터 넘어온 정보
         var rooms = <?=json_encode($rooms)?>;
         var room_type = <?=json_encode($rooms_type)?>;

         // 테이블 구성
         var today = new Date();
         $("#dustmq thead").append('<th width="120px">방번호</th>');
         for(i=0; i<rooms.length; i++){
          var $row = $('<tr name="row_'+rooms[i]+'"><td style="text-align : right;" id="'+rooms[i]+'">'+room_type[i]+' '+rooms[i]+'</td></tr>');
          $("#dustmq tbody").append($row);
            for(k=-5; k<20; k++){
              today.setDate(today.getDate()+k);
              $row.append('<td width="90px" id='+rooms[i]+'_'+getFormatDate2(today)+'></td>');
              today = new Date();
            }
        }

        // 상단 날짜 표시
         for(i=-5; i<20; i++){
         today.setDate(today.getDate()+i);
         $("#dustmq thead").append('<th id="'+getFormatDate2(today)+'" width="40px">'+getFormatDate(today)+'</th>');
         today = new Date();
        }
       });

       function getFormatDate(date){
         var year = date.getFullYear();                                 //yyyy
       	var month = (1 + date.getMonth());                     //M
       	month = month >= 10 ? month : '0' + month;     // month 두자리로 저장
       	var day = date.getDate();                                        //d
       	day = day >= 10 ? day : '0' + day;                            //day 두자리로 저장
       	return  month + '-' + day;
       }

       function getFormatDate2(date){
         var year = date.getFullYear();                                 //yyyy
       	var month = (1 + date.getMonth());                     //M
       	month = month >= 10 ? month : '0' + month;     // month 두자리로 저장
       	var day = date.getDate();                                        //d
       	day = day >= 10 ? day : '0' + day;                            //day 두자리로 저장
       	return  year + '-' + month + '-' + day;
       }

      <!--달력에 예약정보 뿌리기-->
      var res_date = <?=json_encode($res_date)?>;
      var res_room = <?=json_encode($res_room)?>;
      var res_guest = <?=json_encode($res_guest)?>;
      $(document).ready(function(){
          for(i=0; i<res_date.length; i++){
          $("#"+res_room[i]+"_"+res_date[i]).append(res_guest[i]).css("background-color", "yellow");
        }
      })
      </script>

      <!-- datepicker 설정 -->
      <script type="text/javascript">
        $(document).ready(function(){
            $(".datepicker").datepicker({
                    dateFormat: "yy-mm-dd"
                });
            /*
            $("#start_date").datepicker();
            $("#start_date").datepicker("option", "maxDate", $("#end_date").val());
            $("#start_date").datepicker("option", "onClose", function (selectedDate){
              $("#end_date").datepicker("option", "minDate", selectedDate);
            });

            $("#end_date").datepicker();eoqkr123
            $("#end_date").datepicker("option", "minDate", $("#start_date").val());
            $("#end_date").datepicker("option", "onClose", function (selectedDate){
              $("#start_date").datepicker("option", "maxDate", selectedDate);
            });
            */
            });
      </script>

      <!-- 입력창 생성 -->
      <script>
        $(document).ready(function(){
          $("#input_res_btn").click(function(){
            $("#input_res").toggleClass("hidden");
          });
        });
      </script>
 </body>
</html>
